/**
 * FreshPulse — Illustrative Sample Data
 * Clearly identified illustrative dataset for testing and demonstration.
 */

import { StoreRecord } from '../types';

export const ILLUSTRATIVE_SAMPLE_STORES: StoreRecord[] = [
  {
    storeId: 'FP-101',
    storeName: 'Downtown Flagship',
    location: 'Metro Center • Ave 4',
    analysisDate: new Date().toISOString().split('T')[0],
    totalSales: 4850.0,
    transactions: 195,
    footfall: 420,
    inventoryAvailable: 45, // Critically low buffer
    inventorySold: 160,
    wastageQuantity: 8,
    purchaseOrderStatus: 'Delayed',
    staffCount: 5,
    complianceScore: 84,
    notes: 'High lunchtime footfall; distributor shipment delayed 4 hours.'
  },
  {
    storeId: 'FP-104',
    storeName: 'Riverside Fresh',
    location: 'Riverside Walk • North Plaza',
    analysisDate: new Date().toISOString().split('T')[0],
    totalSales: 3200.0,
    transactions: 130,
    footfall: 310,
    inventoryAvailable: 210,
    inventorySold: 130,
    wastageQuantity: 28, // High wastage surge
    purchaseOrderStatus: 'On Time',
    staffCount: 4,
    complianceScore: 71,
    notes: 'Elevated produce spoilage reported in cold produce section.'
  },
  {
    storeId: 'FP-108',
    storeName: 'Suburban Green',
    location: 'West Oaks Shopping Hub',
    analysisDate: new Date().toISOString().split('T')[0],
    totalSales: 5600.0,
    transactions: 220,
    footfall: 460,
    inventoryAvailable: 340, // Healthy balanced buffer
    inventorySold: 180,
    wastageQuantity: 6,
    purchaseOrderStatus: 'Delivered',
    staffCount: 6,
    complianceScore: 92,
    notes: 'Operating smoothly within target operational parameters.'
  },
  {
    storeId: 'FP-112',
    storeName: 'Metro Galleria',
    location: 'Galleria Mall • Ground Concourse',
    analysisDate: new Date().toISOString().split('T')[0],
    totalSales: 1980.0,
    transactions: 65, // Low conversion despite heavy footfall
    footfall: 490,
    inventoryAvailable: 180,
    inventorySold: 70,
    wastageQuantity: 9,
    purchaseOrderStatus: 'On Time',
    staffCount: 3,
    complianceScore: 78,
    notes: 'High footfall traffic passing through, but checkout conversion is lagging.'
  }
];
